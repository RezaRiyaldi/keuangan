<?php
include "_head.php";
include "_sidebar.php";
include "_navbar.php";
include "_content.php";
include "_foot.php";
